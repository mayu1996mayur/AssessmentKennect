/*
import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [repoName, setRepoName] = useState('facebook/react'); // Default repository
  const [issues, setIssues] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [sortBy, setSortBy] = useState('created_at');

  useEffect(() => {
    fetch(`https://api.github.com/repos/${repoName}/issues?per_page=1000`)
      .then((response) => response.json())
      .then((data) => {
        setIssues(data);
      })
      .catch((error) => {
        console.error('Error fetching issues:', error);
      });
  }, [repoName]);

  const handleIssueClick = (issue) => {
    setSelectedIssue(issue);
  };

  const handleCloseModal = () => {
    setSelectedIssue(null);
  };

  const handleSortChange = (event) => {
    setSortBy(event.target.value);
  };

  const sortedIssues = [...issues].sort((a, b) => {
    if (sortBy === 'created_at') {
      return new Date(b.created_at) - new Date(a.created_at);
    } else {
      return a.number - b.number;
    }
  });

  return (
    <div className="App">
      <header className="App-header">
        <h1>GitHub Issue Tracker</h1>
        <label>
          Repository:
          <input
            type="text"
            value={repoName}
            onChange={(e) => setRepoName(e.target.value)}
          />
        </label>
        <div className="Sort-by">
          Sort by:
          <select value={sortBy} onChange={handleSortChange}>
            <option value="created_at">Created Date</option>
            <option value="number">Issue Number</option>
          </select>
        </div>
      </header>
      <main className="App-main">
        <div className="Issue-list">
          <h2>Issues:</h2>
          <ul>
            {sortedIssues.map((issue) => (
              <li key={issue.id}>
                <button onClick={() => handleIssueClick(issue)}>
                  {issue.title}
                </button>
              </li>
            ))}
          </ul>
        </div>
        {selectedIssue && (
          <div className="Issue-details">
            <h2>Issue Details:</h2>
            <button className="Close-button" onClick={handleCloseModal}>
              Close
            </button>
            <pre>{JSON.stringify(selectedIssue, null, 2)}</pre>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;

*/
import React, { useState, useEffect } from 'react';
import './App.css';



function App() {
  const [repoName, setRepoName] = useState('facebook/react'); // Default repository
  const [issues, setIssues] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [sortBy, setSortBy] = useState('created_at');

  useEffect(() => {
    fetch(`https://api.github.com/repos/${repoName}/issues?per_page=1000`)
      .then((response) => response.json())
      .then((data) => {
        setIssues(data);
      })
      .catch((error) => {
        console.error('Error fetching issues:', error);
      });
  }, [repoName]);

  const handleIssueClick = (issue) => {
    setSelectedIssue(issue);
  };

  const handleCloseModal = () => {
    setSelectedIssue(null);
  };

  const handleSortChange = (event) => {
    setSortBy(event.target.value);
  };

  const sortedIssues = [...issues].sort((a, b) => {
    if (sortBy === 'created_at') {
      return new Date(b.created_at) - new Date(a.created_at);
    } else {
      return a.number - b.number;
    }
  });

  // Calculate open and closed issue counts
  const openIssuesCount = issues.filter((issue) => issue.state === 'open').length;
  const closedIssuesCount = issues.filter((issue) => issue.state === 'closed').length;

  // Calculate week-wise issue counts
  const moment = require('moment');

  const getWeekStartDate = (weeksAgo) => {
    return moment().subtract(weeksAgo, 'weeks').startOf('isoWeek').toDate();
  };

  const weekWiseCounts = Array.from({ length: 10 }, (_, index) => {
    const startDate = getWeekStartDate(index);
    const endDate = moment(startDate).endOf('isoWeek').toDate();

    const count = issues.filter((issue) => {
      const createdAt = new Date(issue.created_at);
      return createdAt >= startDate && createdAt <= endDate;
    }).length;

    return {
      startDate,
      endDate,
      count,
    };
  });

  return (
    <div className="App">
       
      <header className="App-header">
        <h1>GitHub Issue Tracker</h1>
        <label>
          Repository:
          <input
            type="text"
            value={repoName}
            onChange={(e) => setRepoName(e.target.value)}
          />
        </label>
        <div className="Sort-by">
          Sort by:
          <select value={sortBy} onChange={handleSortChange}>
            <option value="created_at">Created Date</option>
            <option value="number">Issue Number</option>
          </select>
        </div>
      </header>
      <main className="App-main">
        <div className="Issue-list">
          <h2>Issues:</h2>
          <ul>
            {sortedIssues.map((issue) => (
              <li key={issue.id}>
                <button onClick={() => handleIssueClick(issue)}>
                  {issue.title}
                </button>
              </li>
            ))}
          </ul>
        </div>
        {selectedIssue && (
          <div className="Issue-details">
            <h2>Issue Details:</h2>
            <button className="Close-button" onClick={handleCloseModal}>
              Close
            </button>
            <pre>{JSON.stringify(selectedIssue, null, 2)}</pre>
          </div>
        )}

        <div className="Metrics">
          <h2>Metrics:</h2>
          <p>Open Issues: {openIssuesCount}</p>
          <p>Closed Issues: {closedIssuesCount}</p>
        </div>

        <div className="Week-wise-counts">
          <h2>Week-wise Issue Count:</h2>
          <ul>
            {weekWiseCounts.map((week, index) => (
              <li key={index}>
                {moment(week.startDate).format('YYYY-MM-DD')} to{' '}
                {moment(week.endDate).format('YYYY-MM-DD')}: {week.count} issues
              </li>
            ))}
          </ul>
        
        </div>
      </main>
    </div>
  );
}

export default App;
