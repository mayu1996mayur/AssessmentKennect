document.addEventListener("DOMContentLoaded", function () {
  const startRangeInput = document.getElementById("startRange");
  const endRangeInput = document.getElementById("endRange");
  const findPrimesButton = document.getElementById("findPrimes");
  const resultSection = document.getElementById("result");
  const totalTimeElement = document.getElementById("totalTime");
  const averageTimeElement = document.getElementById("averageTime");
  const showDetailsButton = document.getElementById("showDetails");
  const detailsModal = document.getElementById("detailsModal");
  const tab2B = document.getElementById("tab2B");
  const tab2C = document.getElementById("tab2C");

  findPrimesButton.addEventListener("click", function () {
    const startRange = parseInt(startRangeInput.value);
    const endRange = parseInt(endRangeInput.value);

    const start = performance.now();
    const primes = getPrimesInRange(startRange, endRange);
    const end = performance.now();
    const totalTime = end - start;

    const averageSinglePrimeCheckTime = totalTime / (endRange - startRange + 1);

    totalTimeElement.textContent = totalTime.toFixed(2);
    averageTimeElement.textContent = averageSinglePrimeCheckTime.toFixed(2);

    showDetailsButton.style.display = "inline-block";

    populateTable(primes, tab2B, isPrimeDetailed);
    populateTable([...Array(endRange - startRange + 1).keys()].map((x) => x + startRange), tab2C, isPrime);
  });

  showDetailsButton.addEventListener("click", function () {
    detailsModal.style.display = "block";
  });

  const closeButtons = document.querySelectorAll(".close");
  for (const closeButton of closeButtons) {
    closeButton.addEventListener("click", function () {
      detailsModal.style.display = "none";
    });
  }
});

function getPrimesInRange(start, end) {
  const primes = [];

  for (let num = start; num <= end; num++) {
    if (isPrime(num)) {
      primes.push(num);
    }
  }

  return primes;
}

function isPrime(num) {
  if (num <= 1) return false;
  if (num <= 3) return true;

  if (num % 2 === 0 || num % 3 === 0) return false;

  for (let i = 5; i * i <= num; i += 6) {
    if (num % i === 0 || num % (i + 2) === 0) {
      return false;
    }
  }

  return true;
}

function isPrimeDetailed(num) {
  if (num <= 1) return "Normal";
  if (num <= 3) return "Prime";

  if (num % 2 === 0 || num % 3 === 0) return "Normal";

  for (let i = 5; i * i <= num; i += 6) {
    if (num % i === 0 || num % (i + 2) === 0) {
      return "Normal";
    }
  }

  return "Prime";
}

function populateTable(numbers, table, checkFunction) {
  const tbody = table.querySelector("tbody");
  tbody.innerHTML = "";

  for (const num of numbers) {
    const row = document.createElement("tr");
    const numberCell = document.createElement("td");
    const resultCell = document.createElement("td");
    const timeCell = document.createElement("td");

    numberCell.textContent = num;
    const result = checkFunction(num);
    resultCell.textContent = result;

    const start = performance.now();
    checkFunction(num);
    const end = performance.now();
    timeCell.textContent = (end - start).toFixed(2) + " ms";

    row.appendChild(numberCell);
    row.appendChild(resultCell);
    row.appendChild(timeCell);

    tbody.appendChild(row);
  }
}

function openTab(event, tabName) {
  const tabcontents = document.getElementsByClassName("tabcontent");
  for (const tabcontent of tabcontents) {
    tabcontent.style.display = "none";
  }

  const tablinks = document.getElementsByClassName("tablinks");
  for (const tablink of tablinks) {
    tablink.className = tablink.className.replace(" active", "");
  }

  document.getElementById(tabName).style.display = "block";
  event.currentTarget.className += " active";
}
